SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';


-- -----------------------------------------------------
-- Schema divvybike_snowflake
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `divvybike_snowflake` DEFAULT CHARACTER SET latin1 ;
USE `divvybike_snowflake` ;


-- -----------------------------------------------------
-- Table `divvybike_snowflake`.`dim_station`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `divvybike_snowflake`.`dim_station` (
  `station_key` INT(8) NOT NULL AUTO_INCREMENT,
  `region_key` INT(10) NOT NULL,
  `station_last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `station_id` INT(10) NULL DEFAULT NULL,
  `station_name` VARCHAR(70) NULL DEFAULT NULL,
  `station_total_docks` INT(10) NOT NULL,
  `station_dock_in_service` INT(10) NOT NULL,
  `station_status` VARCHAR (50) NOT NULL,
  `station_zip_code` INT(10) NOT NULL,
  `station_geometry` VARCHAR (200) NOT NULL,
  PRIMARY KEY (`station_key`),
  CONSTRAINT `dim_region_dim_store_fk`
    FOREIGN KEY (`region_key`)
    REFERENCES `divvybike_snowflake`.`dim_region` (`region_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `station_id` USING BTREE ON `divvybike_snowflake`.`dim_station` (`station_id` ASC);
CREATE INDEX `dim_station_last_update` ON `divvybike_snowflake`.`dim_station` (`station_last_update` ASC);
CREATE INDEX `dim_region_dim_station_fk` ON `divvybike_snowflake`.`dim_station` (`region_key` ASC);

-- -----------------------------------------------------
-- Table `divvybike_snowflake`.`dim_region`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `divvybike_snowflake`.`dim_region` (
  `region_key` INT(8) NOT NULL AUTO_INCREMENT,
  `region_last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `region_id` INT(8) NULL DEFAULT NULL,
  `region_name` VARCHAR(100) NULL DEFAULT NULL,
  PRIMARY KEY (`region_key`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `dim_region_last_update` ON `divvybike_snowflake`.`dim_region` (`region_last_update` ASC);

-- -----------------------------------------------------
-- Table `divvybike_snowflake`.`dim_covid`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `divvybike_snowflake`.`dim_covid` (
  `covid_key` INT(8) NOT NULL AUTO_INCREMENT,
  `covid_last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `covid_id` INT(8) NULL DEFAULT NULL,
  `covid_date` DATE NOT NULL,
  `covid_month` INT(3) NOT NULL,
  `covid_day_of_week` INT(3) NOT NULL,
  `covid_confirmed_case_cumulative` INT(10) NULL DEFAULT NULL,
  `covid_confirmed_case_increase` INT(10) NULL DEFAULT NULL,
  `covid_test_case_cumulative` INT(10) NULL DEFAULT NULL,
  `covid_test_case_increase` INT(10) NULL DEFAULT NULL,
  `covid_test_positive_rate` FLOAT NULL DEFAULT NULL,
  PRIMARY KEY (`covid_key`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `dim_covid_last_update` ON `divvybike_snowflake`.`dim_covid` (`covid_last_update` ASC);
CREATE INDEX `dim_covid_date` ON `divvybike_snowflake`.`dim_covid` (`covid_date` ASC);

-- -----------------------------------------------------
-- Table `divvybike_snowflake`.`dim_weather`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `divvybike_snowflake`.`dim_weather` (
  `weather_key` INT(8) NOT NULL AUTO_INCREMENT,
  `weather_last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `weather_id` INT(8) NULL DEFAULT NULL,
  `weather_date` DATE NOT NULL,
  `weather_month` INT(3) NOT NULL,
  `weather_day_of_week` INT(3) NOT NULL,
  `weather_hour` INT(3) NOT NULL,
  `weather_temperature` INT(10) NULL DEFAULT NULL,
  `weather_precipitation` DECIMAL(5,3) NULL DEFAULT NULL,
  `weather_present_weather_type` VARCHAR(50) NULL DEFAULT NULL,
  `weather_relative_humidity` INT(10) NULL DEFAULT NULL,
  `visibility` DECIMAL(5,2) NULL DEFAULT NULL,
  `wind_speed` INT(10) NULL DEFAULT NULL,
  PRIMARY KEY (`weather_key`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `dim_weather_last_update` ON `divvybike_snowflake`.`dim_weather` (`weather_last_update` ASC);
CREATE INDEX `dim_weather_date` ON `divvybike_snowflake`.`dim_weather` (`weather_date` ASC);

-- -----------------------------------------------------
-- Table `divvybike_snowflake`.`dim_traffic`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `divvybike_snowflake`.`dim_traffic` (
  `traffic_key` INT(8) NOT NULL AUTO_INCREMENT,
  `traffic_last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `traffic_date` DATE NOT NULL,
  `traffic_month` INT(10) NOT NULL,
  `traffic_day_of_week` INT(10) NOT NULL,
  `traffic_hour` INT(10) NOT NULL,
  `traffic_avg_speed` DECIMAL(5,2) NULL DEFAULT NULL,
  `traffic_min_speed` DECIMAL(5,2) NULL DEFAULT NULL,
  `traffic_max_speed` DECIMAL(5,2) NULL DEFAULT NULL,
  `traffic_region_id` INT(8) NULL DEFAULT NULL,
  PRIMARY KEY (`traffic_key`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE INDEX `dim_traffic_last_update` ON `divvybike_snowflake`.`dim_traffic` (`traffic_last_update` ASC);
CREATE INDEX `dim_traffic_date` ON `divvybike_snowflake`.`dim_traffic` (`traffic_date` ASC);


-- -----------------------------------------------------
-- Table `divvybike_snowflake`.`fact_trip`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `divvybike_snowflake`.`fact_trip` (
  `trip_key` INT(20) NOT NULL AUTO_INCREMENT,
  `trip_last_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `trip_id` VARCHAR(30) NOT NULL,
  `covid_key` INT(20) NOT NULL,
  `weather_key` INT(20) NOT NULL,
  `traffic_key` INT(20) NOT NULL,
  `start_station_key` INT(20) NOT NULL,
  `start_datetime` DATETIME NOT NULL,
  `start_date` DATE NOT NULL,
  `start_month` INT(10) NOT NULL,
  `start_day_of_week` INT(10) NULL DEFAULT NULL,
  `start_hour` INT(10) NOT NULL,
  `end_station_key` INT(8) NULL DEFAULT NULL,
  `end_datetime` DATETIME NULL DEFAULT NULL,
  `end_date` DATE NULL DEFAULT NULL,
  `end_month` INT(10) NULL DEFAULT NULL,
  `end_day_of_week` INT(10) NULL DEFAULT NULL,
  `end_hour` INT(10) NULL DEFAULT NULL,
  `member` VARCHAR(30) NULL DEFAULT NULL,
  `count_start` INT(10) NOT NULL,
  `count_end` INT(10) NOT NULL,
  `trip_duration` FLOAT NULL DEFAULT NULL,
  PRIMARY KEY (`trip_key`),
  INDEX `dim_covid_fact_trip_fk_idx` (`covid_key` ASC),
  INDEX `dim_weather_fact_trip_fk_idx` (`weather_key` ASC),
  INDEX `dim_traffic_fact_trip_fk_idx` (`traffic_key` ASC),
  INDEX `dim_start_station_fact_trip_fk_idx` (`start_station_key` ASC),
  INDEX `dim_end_station_fact_trip_fk_idx` (`end_station_key` ASC),
  CONSTRAINT `dim_covid_fact_trip_fk`
    FOREIGN KEY (`covid_key`)
    REFERENCES `divvybike_snowflake`.`dim_covid` (`covid_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `dim_weather_fact_trip_fk`
    FOREIGN KEY (`weather_key`)
    REFERENCES `divvybike_snowflake`.`dim_weather` (`weather_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `dim_traffic_fact_trip_fk`
    FOREIGN KEY (`traffic_key`)
    REFERENCES `divvybike_snowflake`.`dim_traffic` (`traffic_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,    
  CONSTRAINT `dim_start_station_fact_trip_fk`
    FOREIGN KEY (`start_station_key`)
    REFERENCES `divvybike_snowflake`.`dim_station` (`station_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `dim_end_station_fact_trip_fk`
    FOREIGN KEY (`end_station_key`)
    REFERENCES `divvybike_snowflake`.`dim_station` (`station_key`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;




SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;