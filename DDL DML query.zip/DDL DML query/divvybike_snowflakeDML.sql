-- -----------------------------------------------------
-- Copy Data from divvybike database 
-- -----------------------------------------------------

# dim_covid table 
# insert data into the dim_covid table from divvybike models covid table 
# Since covid data is originally by zipcode, we need to sum them together to make sure each row stand for daily citywide information.
# Create temp table for transformation

CREATE temporary TABLE IF NOT EXISTS `divvybike`.`dim_covid` (
  `covid_id` INT(8) NOT NULL AUTO_INCREMENT,
  `covid_date` DATE NOT NULL,
  `covid_month` INT(3) NOT NULL,
  `covid_day_of_week` INT(3) NOT NULL,
  `covid_confirmed_case_cumulative` INT(10) NULL DEFAULT NULL,
  `covid_confirmed_case_increase` INT(10) NULL DEFAULT NULL,
  `covid_test_case_cumulative` INT(10) NULL DEFAULT NULL,
  `covid_test_case_increase` INT(10) NULL DEFAULT NULL,
  `covid_test_positive_rate` FLOAT NULL DEFAULT NULL,
  PRIMARY KEY (`covid_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

# insert data into temp table and use sum function

INSERT INTO divvybike.dim_covid (
    covid_date,
    covid_month,
    covid_day_of_week,
    covid_confirmed_case_cumulative,
    covid_confirmed_case_increase,
    covid_test_case_cumulative,
    covid_test_case_increase,
    covid_test_positive_rate)
(SELECT
    date,
    month,
    day_of_week,
    sum(confirmed_cases_cumulative),
    sum(confirmed_cases_increasing),
    sum(tested_cases_cumulative),
    sum(tested_cases_increasing),
    (sum(confirmed_cases_cumulative)/sum(tested_cases_cumulative))
FROM
    divvybike.covid
GROUP BY
    date, month, day_of_week);
    
# We also found that there are 6 days missing in the dataset
    
INSERT INTO divvybike.dim_covid (
    covid_date,
    covid_month,
    covid_day_of_week,
    covid_confirmed_case_cumulative,
    covid_confirmed_case_increase,
    covid_test_case_cumulative,
    covid_test_case_increase,
    covid_test_positive_rate)
VALUES 
   ("2020-05-01",5,4,21770,0,83572,0,0.260494),
   ("2020-06-21",6,6,51546,0,330209,0,0.156101),
   ("2020-06-29",6,0,53092,0,374779,0,0.141662),
   ("2020-07-01",7,2,53501,0,386982,0,0.138252),
   ("2020-10-14",10,2,86935,0,1252633,0,0.0694018),
   ("2020-10-29",10,3,99535,0,1435514,0,0.0693375);

# insert data to snowflake from temporary table

INSERT INTO divvybike_snowflake.dim_covid (
    covid_id,
    covid_date,
    covid_month,
    covid_day_of_week,
    covid_confirmed_case_cumulative,
    covid_confirmed_case_increase,
    covid_test_case_cumulative,
    covid_test_case_increase,
    covid_test_positive_rate)
(SELECT
    covid_id,
    covid_date,
    covid_month,
    covid_day_of_week,
    covid_confirmed_case_cumulative,
    covid_confirmed_case_increase,
    covid_test_case_cumulative,
    covid_test_case_increase,
    covid_test_positive_rate
FROM
    divvybike.dim_covid);
    
# dim_weather table 
# insert data into the dim_weather table from divvybike models weather_by_hour table 

INSERT INTO divvybike_snowflake.dim_weather (
    weather_id,
    weather_date,
    weather_month,
    weather_day_of_week,
    weather_hour,
    weather_temperature,
    weather_precipitation,
    weather_present_weather_type,
    weather_relative_humidity,
    visibility,
    wind_speed)
(SELECT
    weather_id,
    date,
    EXTRACT(MONTH FROM date),
    day_of_week,
    hour,
    dry_bulb_temperature,
    precipitation,
    present_weather_type,
    relative_humidity,
    visibility,
    wind_speed
FROM
    divvybike.weather_by_hour
WHERE date >= "2020-04-01");
    
# dim_region table 
# insert data into the dim_region table from divvybike models region table 

INSERT INTO divvybike_snowflake.dim_region (
    region_id,
    region_name)
(SELECT
    region_id,
    region
FROM
    divvybike.region);
    
# dim_traffic table 
# insert data into the dim_traffic table from divvybike models traffic_by_hour table 

INSERT INTO divvybike_snowflake.dim_traffic (
    traffic_date,
    traffic_month,
    traffic_day_of_week,
    traffic_hour,
    traffic_avg_speed,
    traffic_min_speed,
    traffic_max_speed,
    traffic_region_id)
(SELECT
    DATE,
    MONTH,
    DAY_OF_WEEK,
    HOUR,
    avg_speed,
    min_speed,
    max_speed,
    REGION_ID
FROM
    divvybike.traffic_by_hour
WHERE DATE >= "2020-04-01");  
    
# dim_station table 
# insert data into the dim_station table from divvybike models station table 

INSERT INTO divvybike_snowflake.dim_station ( 
    region_key,
    station_id,
    station_name,
    station_total_docks,
    station_dock_in_service,
    station_status,
    station_zip_code,
    station_geometry)
(SELECT
    region_key,
    ID,
    station_name,
    total_docks,
    dock_in_service,
    status,
    zip_code,
    geometry
FROM
    divvybike.station,
    divvybike_snowflake.dim_region
WHERE 
	divvybike.station.region_id = divvybike_snowflake.dim_region.region_id);
    

-- -----------------------------------------------------
-- DML script here for fact table fact_trip
-- -----------------------------------------------------
# fact_trip table 
# first insert all trip tables together into divvybike.tripsum table

CREATE TABLE IF NOT EXISTS `divvybike`.`trip_sum` (
`ride_id` VARCHAR(10) NOT NULL,
`start_station_id` INT(10) NOT NULL,
`start_datetime` DATETIME NULL DEFAULT NULL,
`start_date` DATE NULL DEFAULT NULL,
`start_month` INT(10) NULL DEFAULT NULL,
`start_day_of_week` INT(10) NULL DEFAULT NULL,
`start_hour` INT(10) NULL DEFAULT NULL,
`end_station_id` INT(10) NULL DEFAULT NULL,
`end_datetime` DATETIME NULL DEFAULT NULL,
`end_date` DATE NULL DEFAULT NULL,
`end_month` INT(10) NULL DEFAULT NULL,
`end_day_of_week` INT(10) NULL DEFAULT NULL,
`end_hour` INT(10) NULL DEFAULT NULL,
`member_casual` VARCHAR(10) NULL DEFAULT NULL)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.10.2020`);
    
    INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.9.2020`);
    
INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.8.2020`);
    
	INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.7.2020`);
    
       INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.6.2020`);
    
INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.5.2020`);
    
INSERT INTO divvybike.`trip_sum` ( 
    ride_id,
    start_station_id,
    start_datetime,
    start_date,
    start_month,
    start_day_of_week,
    start_hour,
    end_station_id,
    end_datetime,
    end_date,
    end_month,
    end_day_of_week,
    end_hour,
    member_casual)
(SELECT
    ride_id,
    start_station_id,
	SUBSTR(concat(started_date," ",started_time),1,length(concat(started_date," ",started_time))-7),
    started_date,
    month(started_date),
    if((dayofweek(started_date)-2)=-1,6,(dayofweek(started_date)-2)),
    hour(started_time),
    end_station_id,
    SUBSTR(concat(ended_date," ",ended_time),1,length(concat(ended_date," ",ended_time))-7),
    ended_date,
    month(ended_date),
    if((dayofweek(ended_date)-2)=-1,6,(dayofweek(ended_date)-2)),
    hour(ended_time),
    member_casual
FROM
	`divvybike`.`trips.4.2020`);
    

-- -----------------------------------------------------
-- DML script for inserting data into fact table fact_trip
-- -----------------------------------------------------

# Insert data into divvybike_snowflake.fact_trip from divvybike.trip_sum

INSERT INTO divvybike_snowflake.fact_trip
( trip_id,
  covid_key,
  weather_key,
  traffic_key,
  start_station_key,
  start_datetime,
  start_date,
  start_month,
  start_day_of_week,
  start_hour,
  end_station_key,
  end_datetime,
  end_date,
  end_month,
  end_day_of_week,
  end_hour,
  member,
  count_start,
  count_end,
  trip_duration)
SELECT 
    divvybike.`trip_sum`.ride_id,
    divvybike_snowflake.dim_covid.covid_key,
    divvybike_snowflake.dim_weather.weather_key, 
	divvybike_snowflake.dim_traffic.traffic_key,
    divvybike_snowflake.dim_station.station_key,
    divvybike.`trip_sum`.start_datetime,
    divvybike.`trip_sum`.start_date,
    divvybike.`trip_sum`.start_month,
    divvybike.`trip_sum`.start_day_of_week,
    divvybike.`trip_sum`.start_hour,
   (SELECT divvybike_snowflake.dim_station.station_key
    FROM divvybike_snowflake.dim_station
    WHERE divvybike.`trip_sum`.end_station_id = divvybike_snowflake.dim_station.station_id) as end_station_key,
    divvybike.`trip_sum`.end_datetime,
    divvybike.`trip_sum`.end_date,
    divvybike.`trip_sum`.end_month,
    divvybike.`trip_sum`.end_day_of_week,
    divvybike.`trip_sum`.end_hour,
    divvybike.`trip_sum`.member_casual,
    IF(divvybike.`trip_sum`.start_date IS NOT NULL,1,0) AS count_start,
    IF(divvybike.`trip_sum`.end_date IS NOT NULL,1,0) AS count_end,
    timestampdiff(minute,divvybike.`trip_sum`.start_datetime,divvybike.`trip_sum`.end_datetime) as trip_duration
FROM divvybike.`trip_sum`
INNER JOIN divvybike_snowflake.dim_station
ON divvybike_snowflake.dim_station.station_id = divvybike.`trip_sum`.start_station_id
INNER JOIN divvybike_snowflake.dim_traffic
ON (divvybike_snowflake.dim_station.region_key = divvybike_snowflake.dim_traffic.traffic_region_id  AND 
	 divvybike_snowflake.dim_traffic.traffic_date = divvybike.`trip_sum`.start_date AND
	 divvybike_snowflake.dim_traffic.traffic_hour = divvybike.`trip_sum`.start_hour)
INNER JOIN divvybike_snowflake.dim_covid
ON divvybike_snowflake.dim_covid.covid_date = divvybike.`trip_sum`.start_date
INNER JOIN divvybike_snowflake.dim_weather
ON (divvybike_snowflake.dim_weather.weather_date = divvybike.`trip_sum`.start_date AND
     divvybike_snowflake.dim_weather.weather_hour = divvybike.`trip_sum`.start_hour);
     
     
     