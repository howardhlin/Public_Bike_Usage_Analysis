-- -----------------------------------------------------
-- Establish dataset "divvybike" and datatable
-- -----------------------------------------------------


SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `divvybike` DEFAULT CHARACTER SET latin1 ;
USE `divvybike` ;

# Create weather table

CREATE TABLE IF NOT EXISTS `divvybike`.`weather_by_hour` (
`weather_id` INT(10) NOT NULL AUTO_INCREMENT,
`time` TIMESTAMP NOT NULL,
`report_type` VARCHAR(20) NOT NULL,
`source` INT(1) NOT NULL,
`altimeter_setting` DECIMAL(5,2) NULL DEFAULT NULL,
`dew_point_temperature` INT(10) NULL DEFAULT NULL,
`dry_bulb_temperature` INT(10) NULL DEFAULT NULL,
`precipitation` DECIMAL(5,3) NULL DEFAULT NULL,
`present_weather_type` VARCHAR(50) NULL DEFAULT NULL,
`presure_change` DECIMAL(5,2) NULL DEFAULT NULL,
`pressure_tendency` DECIMAL(5,1) NULL DEFAULT NULL,
`relative_humidity` INT(10) NULL DEFAULT NULL,
`sealevel_pressure` DECIMAL(5,2) NULL DEFAULT NULL,
`sky_condition` VARCHAR(100) NULL DEFAULT NULL,
`station_pressure` DECIMAL(5,2) NULL DEFAULT NULL,
`visibility` DECIMAL(5,2) NULL DEFAULT NULL,
`wet_bulb_temperature` INT(10) NULL DEFAULT NULL,
`wind_direction` VARCHAR(10) NULL DEFAULT NULL,
`wind_gust_speed` DECIMAL(5,1) NULL DEFAULT NULL,
`wind_speed` INT(10) NULL DEFAULT NULL,
`day_of_week` INT(10) NOT NULL,
`date` DATE NOT NULL,
`hour` INT(10) NOT NULL,
PRIMARY KEY (`weather_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

# Create station table
 
CREATE TABLE IF NOT EXISTS `divvybike`.`station` (
`station_id` INT(10) NOT NULL AUTO_INCREMENT,
`ID` INT(20) NOT NULL,
`station_name` VARCHAR(70) NOT NULL,
`total_docks` INT(10) NOT NULL,
`dock_in_service` INT(10) NOT NULL,
`status` VARCHAR (50) NOT NULL,
`geometry` VARCHAR (200) NOT NULL,
`zip_code` INT(10) NOT NULL,
`region_id` INT(10) NOT NULL,
`region_name` VARCHAR(100) NOT NULL,
PRIMARY KEY (`station_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

# Create traffic table

CREATE TABLE IF NOT EXISTS `divvybike`.`traffic_by_hour` (
`DATE` DATE NOT NULL,
`MONTH` INT(10) NOT NULL,
`DAY_OF_WEEK` INT(10) NOT NULL,
`HOUR` INT(10) NOT NULL,
`avg_speed` DECIMAL(5,2) NULL DEFAULT NULL,
`min_speed` DECIMAL(5,2) NULL DEFAULT NULL,
`max_speed` DECIMAL(5,2) NULL DEFAULT NULL,
`REGION_ID` INT(10) NOT NULL,
`REGION` VARCHAR(100) NOT NULL)
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

# Create region table

CREATE TABLE IF NOT EXISTS `divvybike`.`region` (
`region_id` INT(10) NOT NULL,
`region` VARCHAR(100) NOT NULL,
`geometry` VARCHAR (1000) NOT NULL,
PRIMARY KEY (`region_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

# Create zip_code table

CREATE TABLE IF NOT EXISTS `divvybike`.`zip_code` (
`zip_code` INT(10) NOT NULL,
`geometry` VARCHAR(10000) NOT NULL,
PRIMARY KEY (`zip_code`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

# Create covid table

CREATE TABLE IF NOT EXISTS `divvybike`.`covid` (
    `covid_record_id` INT(10) NOT NULL AUTO_INCREMENT,
    `date` DATE NOT NULL,
    `late_update` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `month` CHAR(10) NULL DEFAULT NULL,
    `day_of_week` CHAR(10) NULL DEFAULT NULL,
    `weekend` CHAR(10) NOT NULL DEFAULT 'Weekday',
    `zipcode` CHAR(10) NOT NULL,
    `confirmed_cases_cumulative` INT(10) NOT NULL,
    `confirmed_cases_increasing` INT(8) NOT NULL,
    `tested_cases_cumulative` INT(10) NOT NULL,
    `tested_cases_increasing` INT(8) NOT NULL,
    `test_positve_rate` FLOAT,
    PRIMARY KEY (`covid_record_id`))
  ENGINE = INNODB 
  DEFAULT CHARACTER SET = LATIN1;
  
  # Create 12 divvybike trip tables for each raw data

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.10.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.9.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.8.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.7.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.6.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


CREATE TABLE IF NOT EXISTS `divvybike`.`trips.5.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.4.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.Q1.2020` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.Q4.2019` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.Q3.2019` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.Q2.2019` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

CREATE TABLE IF NOT EXISTS `divvybike`.`trips.Q1.2019` (
  `ride_id` VARCHAR(10) NOT NULL,
  `start_station_id` INT(10) NOT NULL,
  `start_station_name` VARCHAR(10) NOT NULL,
  `end_station_id` INT(10) NOT NULL,
  `end_station_name` VARCHAR(10) NOT NULL,
  `member_casual` VARCHAR(10) NOT NULL,
  `started_date` DATE NOT NULL,
  `started_time` TIME(6) NOT NULL,
  `ended_date` DATE NOT NULL,
  `ended_time` TIME(6) NOT NULL,
  PRIMARY KEY (`ride_id`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;

-- -----------------------------------------------------
-- Import raw data into divvybike dataset
-- -----------------------------------------------------
# We import raw material into table in Mysql by the following two ways:
## 1. Using "Table Data Import Wizard" to import data into predefined table.
## 2. Uploading raw data into GCP storage and using "Import" function on GCP sql.




