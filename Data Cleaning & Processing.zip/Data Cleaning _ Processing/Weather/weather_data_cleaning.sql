-- -----------------------------------------------------
-- Clean divvybike.weather_by_hour column "sky_condition", and insert the information into column "present_weather_type".
-- -----------------------------------------------------
SET SQL_SAFE_UPDATES=0;
update divvybike.weather_by_hour set present_weather_type = 'clearsky'
where (sky_condition like "%CLR%" or sky_condition like "%FEW%" or sky_condition like "%SCT%") and (present_weather_type="");
SET SQL_SAFE_UPDATES=1;

SET SQL_SAFE_UPDATES=0;
update divvybike.weather_by_hour set present_weather_type = 'Cloudy'
where (sky_condition like "%BKN%" or sky_condition like "%OVC%" or sky_condition like "%VV%") and (present_weather_type="");
SET SQL_SAFE_UPDATES=1;
