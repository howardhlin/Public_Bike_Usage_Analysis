SELECT * FROM divvybike.covid;

# attribute `weekend` update
use divvybike;

# select covid_record_id where day_of_week = 5 or day_of_week = 6;

UPDATE covid
SET weekend = 'weekend'
WHERE 
    EXISTS( select covid_record_id where day_of_week = 5 or day_of_week = 6
);

select * from covid limit 10;

# calculate `test_positive_rate` attribute
UPDATE covid 
SET covid.test_positve_rate =  case when tested_cases_increasing = 0 THEN 0 ELSE confirmed_cases_increasing / tested_cases_increasing * 100 END;

# remove data for 4/18, 4/19
